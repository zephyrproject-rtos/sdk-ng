
int
_getpid (int n)
{
  return 1;
}
